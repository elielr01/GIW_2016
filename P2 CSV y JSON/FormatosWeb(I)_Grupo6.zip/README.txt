-----------------------------------------------------

Práctica 2 - Formatos de datos para la Web(I)
Gestión de Información en la Web
Curso: 2016-2017

Autores:
              Juan Mas Aguilar 
              Lorenzo de la Paz Suárez
              Eli Emmanuel Linares Romero

Grupo 6
              
Facultad de Informática
Universidad Complutense de Madrid
Madrid (Madrid)

------------------------------------------------------

Los tres ejercicios han sido llevados a cabo satisfactoriamente. Sin comentarios
ni precauciones a tener en cuenta.

Versión de Python utilizada : 2.7